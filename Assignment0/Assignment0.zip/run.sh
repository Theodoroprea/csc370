#!/bin/bash


python3 ass1.py $1
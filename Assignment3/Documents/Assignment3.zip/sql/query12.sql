-- Retrieve the display names of every user
-- who has received the Badge that has been
-- awarded the most times, excluding those badges
-- that have been awarded over ten thousand times.
-- Order the result in descending order.
-- 1.1 marks: <12 operators
-- 1.0 marks: <15 operators
-- 0.9 marks: <20 operators
-- 0.8 marks: correct answer

-- Replace this comment line with the actual query
SELECT User.DisplayName FROM User
    JOIN Badge AS b1 ON User.Id = b1.UserId
    JOIN (SELECT Name FROM Badge 
    GROUP BY Name
    HAVING COUNT(Name) <= 10000
    ORDER BY COUNT(Name) DESC
    LIMIT 1) AS b2
   	ON b1.Name = b2.Name
    GROUP BY User.DisplayName
    ORDER BY User.DisplayName DESC;